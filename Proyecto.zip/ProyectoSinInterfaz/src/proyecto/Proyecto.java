/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto;


import AntSystem.SystemAnt;

import Graph.LAGraph;
import Graph.List;
import Graph.VisualizeGraph;
import Txt.Functions;

/**
 *
 * @author gigie
 */
public class Proyecto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.setProperty("org.graphstream.ui", "swing");
        var graph = Functions.loadGraph();
        VisualizeGraph ver = new VisualizeGraph();
        ver.setG(graph);
 //       ver.PrintG(ver.Convert());
 
//        List shortestPath = new List();
//        shortestPath.insertEnd(1, 5.0);
//        shortestPath.insertEnd(2, 4.9);
//        shortestPath.insertEnd(3, 3.0);
//        shortestPath.insertEnd(7, 5.2);
//       

//private static final double p = 0.5; // Tasa de evaporación de feromonas
//    private static final double alpha = 1.0; // Importancia relativa de la feromona
//    private static final double beta = 2.0; // Importancia relativa de la heurística
//    private static int ants; // Número de hormigas
//    private LAGraph dGraph; //Grafo de las distancias
//    private LAGraph pGraph; //Grafo de las feromonas
//    private int iVertex;
//    private int targetVertex;
//    private int cycles;
//    private double tourLength;
//    private static final double q = 1.0;
//    private List antPath;
//    private List bestPath;
//    private double bestPathLength;
//    
// IMPORTANTISIMO CAMBIAR LOS ARGUMENTOS DE SYSTEM ANT, ESTOS LOS PUSE SOLO PARA CORRER EL CODIGO, PERO AHI DEBE IR LO QUE SE RECOJA MEDINATE LA INTERFAZ
        SystemAnt currentSystemAnt =  new SystemAnt(100,graph,5,4 );
        List bestPath = currentSystemAnt.runAS(5);
        ver.highlightPath(bestPath);
    }

}
