/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AntSystem;

import Graph.LAGraph;
import Graph.List;
import Graph.Node;

/**
 * Clase que implementa el algoritmo Ant System
 * El algoritmo se basa en el comportamiento de las hormigas en la búsqueda de comida.
 * @author gigie
 */
public class SystemAnt {
    //Campos de la clase
    private static final double p = 0.5; // Tasa de evaporación de feromonas
    private static final double alpha = 1.0; // Importancia relativa de la feromona
    private static final double beta = 2.0; // Importancia relativa de la heurística
    private static int ants; // Número de hormigas
    private LAGraph dGraph; //Grafo de las distancias
    private LAGraph pGraph; //Grafo de las feromonas
    private int iVertex; //Vértice inicial
    private int targetVertex; //Vértice objetivo
    private int cycles; //No de ciclos
    private double tourLength; //Longitud del recorrido
    private static final double q = 1.0; // Constante q para actualizar las feromonas
    private final List antPath; // Camino de la hormiga actual
    private List bestPath; // Mejor camino encontrado
    private double bestPathLength; //Longitud del mejor camino
    
    /**
     * Constructor de la clase SystemAnt.
     *
     * @param ants          Número de hormigas.
     * @param dGraph        Grafo de distancias.
     * @param ivertex       Vértice inicial.
     * @param targetvertex  Vértice objetivo.
     */
    public SystemAnt(int ants, LAGraph dGraph, int ivertex, int targetvertex) {
        this.ants = ants;
        this.dGraph = dGraph;
        this.pGraph = initializePheromoneGraph(dGraph.getVertexNum());
        this.iVertex = ivertex;
        this.targetVertex = targetvertex;
        this.antPath = new List();
        this.bestPath = new List();
        this.bestPathLength = Double.MAX_VALUE;
    } //Cierre del constructor
    
    /**
     * Método que inicializa el grafo de feromonas con valores iniciales.
     *
     * @param numVertices Número de vértices en el grafo.
     * @return Grafo de feromonas inicializado.
     */
    private LAGraph initializePheromoneGraph(int numVertices) {
        LAGraph pheromoneGraph = new LAGraph();
        pheromoneGraph.insertVertex(numVertices);

        for (int i = 0; i < numVertices ; i++) {
            List aList = dGraph.getAdjList()[i]; 
            for (Node pANode = aList.getpFirst(); pANode != null; pANode = pANode.getpNext())
                pheromoneGraph.insertEdge(i, pANode.getKey(), 1.0/numVertices ,true); // Agrega la cantidad inicial de feromonas al grafo de feromonas
            }

        return pheromoneGraph;
    } //Cierre del método
    
    /**
     * Método que ejecuta el algoritmo Ant System durante el número especificado de ciclos.
     *
     * @param cycles Número de ciclos.
     */
    public void runAS(int cycles) { 
        for (int cycle = 0; cycle < cycles; cycle++) {
            pGraph.printGraph();
            bestPath.clear();
            bestPathLength = Double.MAX_VALUE;
            // Iteración de cada hormiga
            for (int ant = 0; ant < ants; ant++) {
                antPath.clear();
                tourLength = 0.0;
                int currentVertex = iVertex; // Ciudad actual de la hormiga
                antPath.insertEndN(iVertex, 0.0,iVertex);
          
                // Mover la hormiga hasta alcanzar la comida (targetVertex
                
                while (currentVertex != targetVertex ) {
                    int nextVertex = selectNextVertex(currentVertex);
                    if(nextVertex == -1){                       
                        break; 
                    }else{                   
                        
                        tourLength += dGraph.getWeight(currentVertex, nextVertex);
                        antPath.insertEndN(currentVertex, dGraph.getWeight(currentVertex, nextVertex), nextVertex);
                        currentVertex = nextVertex;
                    } 
                }
               
                
                if (currentVertex == targetVertex) {
                        updatePheromone();
                        if(tourLength < getBestPathLength()){
                            bestPath.clear();
                            for(Node pANode = antPath.getpFirst(); pANode != null; pANode = pANode.getpNext()){
                                bestPath.insertEndN(pANode.getKey(), pANode.getWeight(),pANode.getKey2());
                            }                        
                            setBestPathLength(tourLength);   
                        }
                    }
    
                // Realizar la evaporación de feromonas en el grafo de feromonas
                        
            }
            System.out.println("---------------------");
            System.out.println("Camino más eficaz: ");
            bestPath.printList();
            System.out.println("Tamano del camino: "+getBestPathLength());
            System.out.println("----------------");
           
            pGraph = evaporatePheromones();
             
        }
        
    } //Cierre del método
   
    /**
     * Método que selecciona el siguiente vértice de la hormiga a través de probabilística
     *
     * @param currentVertex vértice que se encuentra la hormiga.
     * @return vértice a elegir.
     */
    public int selectNextVertex(int currentVertex) {
        List adjList = dGraph.getAdjVert(currentVertex); // Get the adjacency list of the current vertex
  
   
        for(Node pANode = adjList.getpFirst(), pPrev= null ; pANode != null;pPrev = pANode, pANode = pANode.getpNext() ){
            if(antPath.findValue(pANode.getKey())){
                adjList.removeNode(pANode);        
            }     
        }
                
        int numAdjacentVertices = adjList.getSize(); // Get the number of adjacent vertices
        
   
        
        if(numAdjacentVertices== 0){
            return -1;
        }
        
       
        // Calculate the total sum of heuristics and pheromones for the available paths
        double totalSum = 0.0;
        for (int i = 0; i < numAdjacentVertices; i++) {
            int adjacentVertex = adjList.getValue(i);
            double heuristic = pGraph.getWeight(currentVertex, adjacentVertex); // Use the correct heuristic calculation
            double pheromone = pGraph.getWeight(currentVertex, adjacentVertex);
            totalSum += Math.pow(pheromone, alpha) * Math.pow(heuristic, beta);
        }

        // Calculate the probability for each available path and select one randomly
        double[] probabilities = new double[numAdjacentVertices];
        double randomValue = Math.random(); // Generate a random number between 0 and 1

        int selectedVertex = -1;
        double cumulativeProbability = 0.0;
        for (int i = 0; i < numAdjacentVertices; i++) {
            int adjacentVertex = adjList.getValue(i);
            double heuristic = pGraph.getWeight(currentVertex, adjacentVertex); // Use the correct heuristic calculation
            double pheromone = pGraph.getWeight(currentVertex, adjacentVertex);
            double probability = (Math.pow(pheromone, alpha) * Math.pow(heuristic, beta)) / totalSum;
            probabilities[i] = probability;

            cumulativeProbability += probability;
            if (randomValue <= cumulativeProbability) {           
                selectedVertex = adjacentVertex;
                break;
            }
        }
        
       

        return selectedVertex;
    } //Cierre del método
    
    /**
     * Método que actualiza las feromones del camino que recorrió la hormiga
     */
    public void updatePheromone() {
        double pheromone = q / tourLength;
        
        Node currentNode = antPath.getpFirst();
        Node nextNode = currentNode.getpNext();
        
        while (nextNode != null) {
            int currentVertex = currentNode.getKey();
            int nextVertex = nextNode.getKey();

            double currentPheromone = pGraph.getWeight(currentVertex, nextVertex);
            double updatedPheromone = currentPheromone + pheromone;

            pGraph.setWeight(currentVertex, nextVertex, updatedPheromone);
            pGraph.setWeight(nextVertex, currentVertex, updatedPheromone);
            currentNode = nextNode;
            nextNode = currentNode.getpNext();
        }
    } //Cierre del método 
    
    /**
     * Método que después de una iteración, evapora las feromonas de todos los caminos
     *
     * @return grafo de feromonas actualizado
     */
    public LAGraph evaporatePheromones() {
        int numVertices = pGraph.getVertexNum();
        double pheromone;
         
        LAGraph pheromoneGraph = new LAGraph();
        pheromoneGraph.insertVertex(numVertices);
        
        for (int i = 0; i < numVertices ; i++) {
            List aList = dGraph.getAdjList()[i]; 
            for (Node pANode = aList.getpFirst(); pANode != null; pANode = pANode.getpNext()){
                pheromone = pGraph.getWeight(i, pANode.getKey());
                pheromone = (1 - p) * pheromone;
                pheromoneGraph.insertEdge(i, pANode.getKey(), pheromone ,true); // Agrega la cantidad inicial de feromonas al grafo de feromonas
            }
        
        }
        return pheromoneGraph;
        } //Cierre del método
    
   
    /**
     * Método que devuelve el vértice inicial.
     * @return the iVertex
     */
    public int getiVertex() {
        return iVertex;
    } //Cierre del método

    /**
     * Método que establece el vértice inicial.
     * @param iVertex the iVertex to set
     */
    public void setiVertex(int iVertex) {
        this.iVertex = iVertex;
    } //Cierre del método

    /**
     * Método que devuelve el vértice objetivo.
     * @return the targetVertex
     */
    public int getTargetVertex() {
        return targetVertex;
    } //Cierre del método

    /**
     * Método que establece el vértice objetivo.
     * @param targetVertex the targetVertex to set
     */
    public void setTargetVertex(int targetVertex) {
        this.targetVertex = targetVertex;
    } //Cierre del método

    /**
     * Método que devuelve el grafo de las distancias.
     * @return the dGraph
     */
    public LAGraph getdGraph() {
        return dGraph;
    } //Cierre del método

    /**
     * Método que establece el grafo de las distancias.
     * @param dGraph the dGraph to set
     */
    public void setdGraph(LAGraph dGraph) {
        this.dGraph = dGraph;
    } //Cierre del método
    
    /**
     * Método que devuelve el grafo de las feromonas.
     * @return grafo de las feromonas
     */
    public LAGraph getpGraph() {
        return pGraph;
    } //Cierre del método

    /**
     * Método que establece el grafo de las feromonas.
     * @param pGraph the dGraph to set
     */
    public void setpGraph(LAGraph pGraph) {
        this.pGraph = pGraph;
    } //Cierre del método

    /**
     * Método que devuelve el número de ciclos.
     * @return the cycles
     */
    public int getCycles() {
        return cycles;
    } //Cierre del método

    /**
     * Método que establece el número de ciclos.
     * @param cycles the cycles to set
     */
    public void setCycles(int cycles) {
        this.cycles = cycles;
    } //Cierre del método

    /**
     * Método que devuelve el número de hormigas.
     * @return the ants
     */
    public int getAnts() {
        return ants;
    } //Cierre del método

    /**
     * Método que establece el número de hormigas.
     * @param ants the ants to set
     */
    public void setAnts(int ants) {
        this.ants = ants;
    } //Cierre del método

    /**
     * Método que devuelve el mejor camino.
     * @return the bestPath
     */
    public List getBestPath() {
        return bestPath;
    } //Cierre del método

    /**
     * Método que establece el mejor camino.
     * @param bestPath the bestPath to set
     */
    public void setBestPath(List bestPath) {
        this.bestPath = bestPath;
    } //Cierre del método

    /**
     * Método que devuelve la longitud del mejor camino.
     * @return the bestPathLength
     */
    public double getBestPathLength() {
        return bestPathLength;
    } //Cierre del método

    /**
     * Método que establece la longitud del mejor camino.
     * @param bestPathLength the bestPathLength to set
     */
    public void setBestPathLength(double bestPathLength) {
        this.bestPathLength = bestPathLength;
    } //Cierre del método 

} //Cierre de la clase
 
    
    
   