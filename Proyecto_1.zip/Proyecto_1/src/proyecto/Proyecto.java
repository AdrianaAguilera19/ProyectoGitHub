/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto;


import AntSystem.SystemAnt;

import Graph.LAGraph;
import Graph.List;
import Txt.Functions;

/**
 *
 * @author gigie
 */
public class Proyecto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Create a sample graph
        LAGraph graph = new LAGraph();
        graph.insertVertex(8);  // Vertex 0
        
        
        //var graph1 = Functions.loadGraph();
        //graph1.printGraph();
        //Functions.writeGraph(graph1);
       

        // Add edges with weights
        graph.insertEdge(0, 1, 2.0, false);
        graph.insertEdge(0, 1, 20.0, false);
        graph.insertEdge(1, 2, 1.5, false);
        graph.insertEdge(4, 3, 10.45, false);
        graph.insertEdge(1, 5, 2.0, false);
        graph.insertEdge(2, 3, 20.0, false);
        graph.insertEdge(3, 1, 1.5, false);
        graph.insertEdge(5, 4, 2.5, false);
        graph.insertEdge(6, 4, 2.0, false);
        graph.insertEdge(7, 6, 20.0, false);
        graph.insertEdge(0, 1, 1.5, false);
        graph.insertEdge(1, 6, 2.5, false);
        graph.insertEdge(2, 6, 2.0, false);
        graph.insertEdge(6, 3, 20.0, false);
        graph.insertEdge(5, 7, 1.5, false);
        graph.insertEdge(2, 4, 10.5, false);
        graph.insertEdge(5, 6, 2.0, false);
        graph.insertEdge(4, 4, 20.0, false);
        graph.insertEdge(5, 2, 1.5, false);
        graph.insertEdge(6, 5, 2.5, false);
        

        graph.printGraph();
        
        
        SystemAnt antSystem = new SystemAnt(100,graph,0,7);
        
        
       
        
        antSystem.runAS(2);
        
        
    
        
  
        
       
    }


}