/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Graph;

/**
 * Clase que representa un nodo en un grafo.
 * @author gigie
 */
public class Node {
    //Campos de la clase
    private int key;
    private int key2;
    private double weight;
    private Node pNext;
    
    /**
     * Constructor de un nodo para la creación de un grafo
     * Crea un nuevo nodo con la clave y el peso especificados.
     * 
     * @param data la clave del nodo (vértice)
     * @param w el peso del nodo (distancia)
     */
    public Node (int data, double w){
        key = data;
        weight = w;
        pNext = null;
    }//Cierre del constructor
    
    public Node (int iV, int nV, double w){
        key = iV;
        key2 = nV;
        weight = w;
        pNext = null;
    }
    
    /**
     * Constructor que crea un nuevo nodo con la clave especificada.
     * 
     * @param data la clave del nodo 
     */
    public Node (int data){
        key = data;
        pNext = null;
    } //Cierre del constructor

    /**
     * Método que devuelve la clave del nodo.
     * 
     * @return the key
     */
    public int getKey() {
        return key;
    } //Cierre del método 
    
     public int getKey2() {
        return key2;
    } //Cierre del método 

    /**
     * Método que establece la clave del nodo.
     * 
     * @param key the key to set
     */
    public void setKey(int key) {
        this.key = key;
    } //Cierre del método

    /**
     * Método que devuelve el siguiente nodo.
     * 
     * @return the pNext
     */
    public Node getpNext() {
        return pNext;
    } //Cierre del método 
    

    /**
     * Método que establece el siguiente nodo.
     * 
     * @param pNext the pNext to set
     */
    public void setpNext(Node pNext) {
        this.pNext = pNext;
    } //Cierre del método

    /**
     * Método que devuelve el peso del nodo.
     * 
     * @return the weight
     */
    public double getWeight() {
        return weight;
    } //Cierre del método

    /**
     * Método que establece el peso del nodo
     * 
     * @param weight the weight to set
     */
    public void setWeight(double weight) {
        this.weight = weight;
    } //Cierre del método
    
    /**
     * Método que añade un peso adicional al peso actual del nodo.
     * 
     * @param w el peso adicional a añadir
     */
    public void addWeight(double w) {
        this.weight = this.weight + w;
    } //Cierre del método
    
} //Cierre de la clase
