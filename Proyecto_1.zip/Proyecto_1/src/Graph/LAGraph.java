/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Graph;

/**
 * Esta clase representa un grafo utilizando una lista de adyacencia.
 * @author gigie
 */
public class LAGraph {
    //Campos de la clase
    private final int maxNodes;
    private int vertexNum;
    private final List[] adjList;
    
    /**
     * Constructor de una instancia de la clase LAGraph con valores predeterminados, para crear un grafo.
     */
    public LAGraph () {
        maxNodes = 20;
        vertexNum = 0;
        adjList = new List[20];
    } //Cierre del constructor
    
    /**
     * Método que inserta una arista entre dos vértices con un peso opcional.
     *
     * @param i      el índice del primer vértice
     * @param j      el índice del segundo vértice
     * @param weight el peso de la arista
     * @param ind    indica si la arista es dirigida o no dirigida
     */
    public void insertEdge (int i, int j, double weight, boolean ind) {
        if (i >= getVertexNum())
            System.out.println("Error no existe el vertice en el grafo");
        else {
            getAdjList()[i].insertEnd(j, weight);   
            if (ind == false) {
                getAdjList()[j].insertEnd(i, weight);
            }
        }
    } //Cierre del método
    
    /**
     * Método que elimina una arista entre dos vértices.
     *
     * @param i el índice del primer vértice
     * @param j el índice del segundo vértice
     */
    public void removeEdge (int i, int j){
        if (j >= getVertexNum())
            System.out.println("Error no existe el vertice en el grafo");
        else {
            getAdjList()[i].removeValue(j);
            getAdjList()[j].removeValue(i);
        }
    } //Cierre del método
    
    /**
     * Método que inserta un número especificado de vértices en el grafo.
     *
     * @param n el número de vértices a insertar
     */
    public void insertVertex(int n){
        if (n > getMaxNodes() - getVertexNum())
            System.out.println("Error, se supera el numero de nodos maximo del grafo");
        else if(n < 4)
            System.out.println("Error, no supera el numero minimo de nodos en el grafo");
        else
            for(int i = getVertexNum(); i < getVertexNum() + n; i++)
                adjList[i] = new List();
        vertexNum += n;
    } //Cierre del método
    
    /**
     * Método que actualiza el peso de una arista entre dos vértices.
     *
     * @param i      el índice del primer vértice
     * @param j      el índice del segundo vértice
     * @param weight el nuevo peso de la arista
     */
    public void updateWeightEdge(int i, int j, double weight) {
        if (i >= getVertexNum() || j >= getVertexNum()) {
            System.out.println("Error: uno o ambos vértices no existen en el grafo.");
            return;
        }

        Node current = getAdjList()[i].getpFirst();
        while (current != null) {
            if (current.getKey() == j) {
                current.setWeight(weight);
                break;
            }
            current = current.getpNext();
        }

        current = getAdjList()[j].getpFirst();
        while (current != null) {
            if (current.getKey() == i) {
                current.setWeight(weight);
                break;
            }
            current = current.getpNext();
        }
    } //Cierre del método
    
    /**
     * Método que elimina un vértice del grafo.
     *
     * @param vertex el índice del vértice a eliminar
     */
    public void removeVertex(int vertex) {
        // Verificar si el vértice existe en el grafo
        if (vertex < 0 || vertex >= vertexNum) {
            System.out.println("El vértice especificado no existe en el grafo.");
            return;
        }

        // Eliminar todas las aristas incidentes al vértice
        List adjVertices = adjList[vertex];
        for (int i = 0; i < vertexNum; i++) {
            if (i != vertex) {
                List adjacentList = adjList[i];
                adjacentList.removeValue(vertex);
            }
        }

        // Eliminar la lista de adyacencia del vértice
        adjVertices = null;

        // Actualizar el número de vértices en el grafo
        vertexNum--;

        // Actualizar los índices de los vértices posteriores al eliminado
        for (int i = vertex; i < vertexNum; i++) {
            adjList[i] = adjList[i + 1];
        }

        // Liberar el último índice
        adjList[vertexNum] = null;
    } //Cierre del método
    
    /**
     * Método que calcula el grado de entrada de un vértice.
     *
     * @param v el índice del vértice
     * @return el grado de entrada del vértice
     */
    public int inGrade (int v) {
        int gIn = 0;
        for (int i =0; i < getVertexNum(); i++)
            if (i != v)
                if (getAdjList()[i].findValue(v))
                    gIn++;
        return gIn;
    } //Cierre del método
    
    /**
     * Método que calcula el grado de salida de un vértice.
     *
     * @param i el índice del vértice
     * @return el grado de salida del vértice
     */
    public int outGrade(int i) {
        int gOut = 0;
        Node aux = getAdjList()[i].getpFirst();
        
        while (aux != null){
            gOut++;
            aux = aux.getpNext();
        }
        return gOut;
    } //Cierre del método
    
    /**
     * Método que calcula la incidencia de un vértice.
     *
     * @param i el índice del vértice
     * @return la incidencia del vértice
     */
    public int incidence (int i){
       return inGrade (i) + outGrade (i);
    } //Cierre del método
    
    /**
     * Método que calcula el tamaño del grafo
     *
     * @return el tamaño del grafo
     */
    public int size() {
        int sz = 0;
        
        for (int i = 0; i<getVertexNum(); i++)
            sz += numElements (getAdjList()[i]);
        
        return sz;
    } //Cierre del método
    
    /**
     * Método que devuelve el número de elementos de un vértice.
     *
     * @param lista la lista que se quiere conocer su tamaño
     * @return el tamaño
     */
    static int numElements (List list) {
        Node aux = list.getpFirst();
        int result = 0;
        while (aux != null) {
            result +=1;
            aux = aux.getpNext();
        }
        return result;
    } //Cierre del método
    
    /**
     * Método que imprime el grafo
     */
    public void printGraph () {
        System.out.println("Tamaño máximo del grafo: " + getMaxNodes() + "\n");
        System.out.println("El grafo contiene " + getVertexNum() + " vértices: \n");
        for (int i = 0; i < getVertexNum(); i++) {
            System.out.print ("vértice " + i + ": ");
            write (getAdjList() [i]);
        }
    } //Cierre del método
    
    /**
     * Método que imprime los valores de una lista.
     *
     * @param list la lista a imprimir
     */
    static void write (List list) {
        Node aux;
        aux = list.getpFirst();
        while (aux != null) {
            System.out.print (aux.getKey() +"(" + aux.getWeight()+ ")" + ",");
            aux = aux.getpNext();
        }
        System.out.println("FIN");
    } //Cierre del método
    
    /**
     * 
     * Método que devuelve el número máximo de nodos permitidos en el grafo.
     * 
     * @return the maxNodes
     */
    public int getMaxNodes() {
        return maxNodes;
    } //Cierre del método

    /**
     * Método que devuelve el número actual de vértices en el grafo.
     * 
     * @return the vertexNum
     */
    public int getVertexNum() {
        return vertexNum;
    } //Cierre del método

    /**
     * Método que devuelve la lista de adyacencia del grafo.
     * 
     * @return the adjList
     */
    public List[] getAdjList() {
        return adjList;
    } //Cierre del método
    
    /**
     * Método que devuelve la lista de un vértice.
     * 
     * @param vertex vértice que se desea ver su lista
     * @return the adjList[vertex]
     */
    public List getAdjVert(int vertex) {
        return adjList[vertex];
    } //Cierre del método
    
    /**
     * Método que devuelve el peso de un vértice
     * 
     * @param i      el índice del primer vértice
     * @param j      el índice del segundo vértice
     * 
     * @return the weight
     */
    public double getWeight(int i, int j) {
    Node current = adjList[i].getpFirst();
    while (current != null) {
        if (current.getKey() == j) {
            return current.getWeight();
        }
        current = current.getpNext();
    }
    return -1;
    } //Cierre del método
  
    /**
     * Método que establece el número de vértices de un grafo.
     * @param vertexNum the vertexNum to set
     */
    public void setVertexNum(int vertexNum) {
        this.vertexNum = vertexNum;
    } //Cierre del método
   
    /**
     * Método que establece el peso entre dos vértices
     * @param i primer vértice
     * @param j segundo vértice
     * @param w peso nuevo entre los vértices
     */
    public void setWeight(int i, int j, double w) {
        Node current = adjList[i].getpFirst();
        while (current != null) {
            if (current.getKey() == j) {
                current.setWeight(w);
            }
            current = current.getpNext();
        }
        } //Cierre del método
    
    
    
} //Cierre de la clase
