/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Graph;

/**
 * Clase representa una lista en un grafo implementando listas de adyacencia.
 * @author gigie
 */
public class List {
    //Campos de la clase
    private Node pFirst;
    private Node pLast;
    private int size;
    
    /**
     * Constructor que crea una nueva lista vacía.
     */
    public List() {
        pFirst = null;
        pLast = null;
        size = 0;
    } //Cierre del constructor
    
    /**
     * Método que inserta un nuevo nodo al final de la lista con el valor y peso especificados.
     * 
     * @param value el valor del nuevo nodo
     * @param weight el peso del nuevo nodo
     */
    public void insertEnd(int value, double weight) {
        Node pNode = new Node(value, weight);
        
        if (size == 0){
            pFirst = pLast = pNode;
        } else{
            pLast.setpNext(pNode);
            pLast = pNode;
        }
        size++;
    } //Cierre del método
    
    /**
     * Método que inserta un nuevo nodo al final de la lista con el valor especificado.
     * 
     * @param value el valor del nuevo nodo
     */
    public void insertEndN(int value, double weight, int value2) {
        Node pNode = new Node(value, value2, weight);
        
        if (size == 0){
            pFirst = pLast = pNode;
        } else{
            pLast.setpNext(pNode);
            pLast = pNode;
        }
        size++;
    } //Cierre del método
    
    /**
     * Método que elimina el primer nodo de la lista que tiene el valor especificado.
     * 
     * @param value el valor del nodo a eliminar
     * @return el valor del nodo eliminado, o 0 si no se encontró el valor
     */
    public int removeValue(int value) {
        if(size == 0) {
            return 0;
        } 
        for(Node pANode = pFirst, pPrev = null; pANode != null; pPrev = pANode, pANode = pANode.getpNext()){
            if (java.util.Objects.equals(pANode.getKey(), value)) {
                if (pANode == pFirst){
                    pFirst = pANode.getpNext();
                }else {
                    pPrev.setpNext(pANode.getpNext());
                }
                if (pANode == getpLast()){
                    pLast = pPrev;
                }
                size--;
                return pANode.getKey();
            }
        }
        return 0; 
            
    } //Cierre del método
    
    /**
     *Método que verifica si la lista contiene un nodo con el valor especificado.
     * 
     * @param value el valor a buscar
     * @return true si la lista contiene el valor, false en caso contrario
     */
    public boolean findValue(int value){
        if(pFirst.getKey() == value){
            return true;
        }
        
        for(Node pANode = pFirst; pANode != null; pANode = pANode.getpNext()){
            if (java.util.Objects.equals(pANode.getKey(), value)) {
                return true;
            }  
        }
        return false;
    } //Cierre del método
    
    /**
     * Método que obtiene el valor del nodo en la posición especificada.
     * 
     * @param index el índice del nodo
     * @return el valor del nodo en la posición especificada
     * @throws IndexOutOfBoundsException si el índice está fuera de rango
     */
    public int getValue(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Invalid index");
        }

        Node currentNode = pFirst;
        int currentIndex = 0;

        while (currentIndex < index) {
            currentNode = currentNode.getpNext();
            currentIndex++;
        }

        return currentNode.getKey();
    } //Cierre del método
    
    /**
     * Método que imprime los valores de los nodos en la lista.
     */
    public void printList() {
    Node currentNode = pFirst;

    while (currentNode != null) {
        System.out.print(currentNode.getKey2() + " (" + currentNode.getWeight() + ") ");
        currentNode = currentNode.getpNext();
    }

    System.out.println();
    } //Cierre del método
    
    public void printList2() {
    Node currentNode = pFirst;

    while (currentNode != null) {
        System.out.print(currentNode.getKey() + " " + currentNode.getKey2() +  " "+ currentNode.getWeight()+ "/");
        currentNode = currentNode.getpNext();
    }

    System.out.println();
    } 
    
    /**
     * Método que elimina todos los nodos de la lista, dejándola vacía.
     */
    public void clear() {
        pFirst = null;
        pLast = null;
        size = 0;
    } //Cierre del método
    
    /**
     * Método que elimina un nodo específico de la lista.
     * 
     * @param node el nodo a eliminar
     */
    public void removeNode(Node node) {
        if (size == 0) {
            return;
        }

        if (pFirst == node) {
            pFirst = node.getpNext();
        }else{
            for(Node pPrev = null, pANode = pFirst; pANode != null; pPrev = pANode, pANode = pANode.getpNext()){
                if(pANode == node){
                    if (pANode.getpNext() == null){
                        pPrev.setpNext(null);
                    } else {
                    pPrev.setpNext(pANode.getpNext());
                    }
                }
            }
        }


        size--;
    } //Cierre del método
 
    /**
     * Método que obtiene el primer nodo de la lista.
     * @return the pFirst
     */
    public Node getpFirst() {
        return pFirst;
    } //Cierre del método

    /**
     * Método que establece el primer nodo de la lista.
     * @param pFirst the pFirst to set
     */
    public void setpFirst(Node pFirst) {
        this.pFirst = pFirst;
    } //Cierre del método

    /**
     * Método que devuelve el último nodo de la lista
     * @return the pLast
     */
    public Node getpLast() {
        return pLast;
    } //Cierre del método

    /**
     * Método que establece el último nodo de la Lista
     * @param pLast the pLast to set
     */
    public void setpLast(Node pLast) {
        this.pLast = pLast;
    } //Cierre del método

    /**
     * Método que devuelve el tamaño de la lista
     * @return the size
     */
    public int getSize() {
        return size;
    } //Cierre del método
    
} //Cierre de la clase
